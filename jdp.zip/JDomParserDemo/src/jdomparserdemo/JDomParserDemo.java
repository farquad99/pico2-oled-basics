package jdomparserdemo;

/**
 *
 * @author tom
 */
import java.io.File;

//import java.util.logging.Logger;

//import org.jdom2.Attribute;
import org.jdom2.Document;
//import org.jdom2.Content;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JDomParserDemo {

    public static void main(String[] args) {
        // get properties
        Properties props = new Properties();
        FileInputStream in = null;
        try {
            in = new FileInputStream("parser.properties");
            props.load(in);

        } catch (IOException ex) {

            Logger lgr = Logger.getLogger(JDomParserDemo.class.getName());
            lgr.log(Level.SEVERE, ex.getMessage(), ex);

        } finally {

            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException ex) {
                Logger lgr = Logger.getLogger(JDomParserDemo.class.getName());
                lgr.log(Level.SEVERE, ex.getMessage(), ex);
            }
        }
        // props invullen
        String workdir = props.getProperty("werkmap");
        String basis = props.getProperty("basisnaam");
        
        try {
            File inputFile = new File(args[0]); //workdir/basis 

            SAXBuilder saxBuilder = new SAXBuilder();

            Document document = saxBuilder.build(inputFile);

            //System.out.println("Root element :" + document.getRootElement().getName());
            Element root = document.getRootElement();

            Element lokaal = root.getChild("lokaalMeetstelsel", Namespace.getNamespace("gml", "http://www.kadaster.nl/gml"));
            // veldwerk
            Element vw = lokaal.getChild("veldwerk", Namespace.getNamespace("gml", "http://www.kadaster.nl/gml"));
            String message = vw.getAttributeValue("kadGemCode");
            System.out.println("veldwerk Kadgemcode: " + message);
            message = vw.getAttributeValue("sectie");
            System.out.println("veldwerk Sectie " + message);
            message = vw.getText();
            System.out.println("veldwerk nummer: " + message);
            Element naam = lokaal.getChild("naam", Namespace.getNamespace("gml", "http://www.kadaster.nl/gml"));
            message = naam.getText();
            System.out.println("naam : " + message);
            // datum
            Element datum = lokaal.getChild("datum", Namespace.getNamespace("gml", "http://www.kadaster.nl/gml"));
            message = datum.getText();
            System.out.println("datum : " + message);
            //bronVermelding
            Element bronVermelding = lokaal.getChild("bronVermelding", Namespace.getNamespace("gml", "http://www.kadaster.nl/gml"));
            message = bronVermelding.getText();
            System.out.println("Bron : " + message);
            //coordinatenStelsel
            Element coordstelsel = lokaal.getChild("coordinatenStelsel", Namespace.getNamespace("gml", "http://www.kadaster.nl/gml"));
            message = coordstelsel.getText();
            System.out.println("coordinatenStelsel : " + message);
            String xybuf[];
            // terreinPunt
            /* */
            for (Element terpunt : lokaal.getChildren("terreinPunt", Namespace.getNamespace("gml", "http://www.kadaster.nl/gml"))) {
                if (terpunt != null) {
                    Element pnum = terpunt.getChild("puntNummer", Namespace.getNamespace("gml", "http://www.kadaster.nl/gml"));
                    message = pnum.getText();
                    System.out.println("puntNummer : " + message);
                    //classificatieCode
                    Element classCode = terpunt.getChild("classificatieCode", Namespace.getNamespace("gml", "http://www.kadaster.nl/gml"));
                    message = classCode.getText();
                    System.out.println("classificatie : " + message);
                    //precisieKlasse
                    Element presis = terpunt.getChild("precisieKlasse", Namespace.getNamespace("gml", "http://www.kadaster.nl/gml"));
                    message = presis.getText();
                    System.out.println("precisieKlasse : " + message);

                    Element wijze = terpunt.getChild("wijzeInwinning", Namespace.getNamespace("gml", "http://www.kadaster.nl/gml"));
                    message = wijze.getText();
                    System.out.println("wijze van Inwinning : " + message);
                    Element punt = terpunt.getChild("Point", Namespace.getNamespace("gml", "http://www.opengis.net/gml")); //verwarrend
                    //System.out.println(punt.toString());
                    // child coordinates van Point
                    Element coords = punt.getChild("coordinates", Namespace.getNamespace("gml", "http://www.opengis.net/gml"));
                    message = coords.getText();
                    // coordinaten splitsen ??
                    xybuf = message.split(","); // java.lang.String
                    
                    //System.out.print("coordinaten : " + message );
                    System.out.print(" x :" + xybuf[0]);
                    System.out.println(" y :" + xybuf[1]);
                }
            }

        } catch (JDOMException e) {
            e.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }
}
